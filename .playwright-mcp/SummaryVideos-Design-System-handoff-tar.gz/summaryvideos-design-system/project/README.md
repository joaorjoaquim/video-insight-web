# SummaryVideos Design System — *Briefing Room*

A design system for **SummaryVideos** — an AI-powered tool that turns public video URLs into structured knowledge. Paste a YouTube/Vimeo/Twitter link; the product downloads, transcribes, and analyses the content, then returns a summary, time-stamped transcript, thematic insights, and an interactive mind map. Credits fund processing.

---

## Why this system is shaped the way it is

The product is a **time-compression tool** — long video in, short brief out. So the interface borrows the language of a **broadcast briefing room**: cool workshop ground, SMPTE-style timecodes, broadcast-LED status indicators, and the **logo's own play triangle and horizontal bars** as the unifying visual motif used everywhere.

> The two anchors of the system — Signal Orange and Insight Purple — are not arbitrary brand colors. They are the actual orange of the logo's **play triangle** and the actual purple of the logo's **bars**. Everything else descends from those.

This is a deliberate departure from "AI SaaS" defaults:

| Default | What this system does instead |
|---|---|
| Inter + soft pastel pills | **Instrument Serif** display + **IBM Plex Sans** UI + **IBM Plex Mono** for timecodes/status |
| Pastel rounded "pill" status chips | **Broadcast LEDs**: small filled dot + mono lowercase label, transcribing pulses |
| Spinners on loading | **Bars loader** — the logo's bars filling in left-to-right with stagger |
| Generic gradient hero text | **Italic-orange word** with a logo-bar underline accent |
| Section icons (emoji or generic) | **The actual logo bars** as the section marker glyph |
| Card shadows / lift on hover | **Cool ground, hairline borders, density**. Hover changes color, never size |
| Indigo-purple gradient buttons | **Solid orange CTA with the play-triangle glyph** |

---

## Logo DNA — how the mark drives the system

```
   ┌────────────────────────────────────────────────────┐
   │                                                    │
   │   ▶   ━━━━━━━━━━            play-triangle ──► CTA  │
   │       ━━━━━━━━━━━━━              bars ──► insight  │
   │       ━━━━━━━                                      │
   │                                                    │
   └────────────────────────────────────────────────────┘
```

| Logo element | Used in product as |
|---|---|
| **Orange play triangle** | The glyph on every primary CTA button (`.play-glyph`); the active-tab underline; the focus indicator on inputs; the timecode chip color. |
| **Purple horizontal bars (3, staggered widths)** | The `.logo-bars` section marker placed before every page H1 and section heading. The bars loader. The pull-quote left accent (3 stacked bars, not a single rule). |
| **Bars + triangle pair** | The brand mark in the header; never recoloured, never re-arranged. |

This pattern is the single most important rule of the system. Before drawing anything new, ask: *can this be expressed with the bars or the triangle?* Often the answer is yes.

---

## Sources

This system was extracted from and is informed by the official frontend codebase:

- **Local codebase** (mounted): `video-insight-web/` — Next.js 15 + Tailwind v4 + shadcn/ui + Hugeicons.
- **GitHub repo:** https://github.com/joaorjoaquim/video-insight-web — browse `src/app/page.tsx` (landing), `src/app/(private)/dashboard/page.tsx`, `src/app/(private)/wallet/page.tsx`, `src/app/(private)/submissions/[id]/page.tsx`, and `src/components/` for the canonical structure. We replicate behaviour, not visual treatment.
- **API repo:** https://github.com/joaorjoaquim/video-insight-api
- **Live product:** https://summaryvideos.com
- **Logo asset:** `video-insight-web/public/summary_videos_logo.png` → copied to `assets/summary_videos_logo.png`. Untouched — its colors seed the whole palette.

If you have access, **always cross-check the codebase** for route structure, copy, status names, credit-package amounts, and screen layouts. This design system intentionally reshapes the *visual* layer.

---

## Surfaces

| Surface | Route(s) | Register |
|---|---|---|
| **Marketing landing** | `/` (unauth) | Briefing-room cool off-white. Cinematic Instrument Serif hero. Animated bars loader as a hero visual element. Orange play-triangle CTA. |
| **Authed workshop** | `/dashboard`, `/wallet`, `/submissions/[id]` | Same ground, denser. Mono metadata. Index cards with a coloured "tape-label tab" along one edge. Broadcast LEDs for status. |
| **Auth dialog** | Modal | Paper card centered on deep ink scrim. Underline-only fields with mono labels. |

---

## What's in this folder

| Path | What |
|---|---|
| `README.md` | This file — start here |
| `MOTION.md` | Motion principles, tokens, and 10 named scenes |
| `SKILL.md` | Skill manifest — usable as an Agent Skill in Claude Code |
| `colors_and_type.css` | All tokens as CSS custom properties — `@import` this |
| `assets/summary_videos_logo.png` | Brand logo (unchanged) |
| `preview/*.html` | Standalone design-system preview cards |
| `ui_kits/web-app/` | Hi-fi React recreation of every product screen |
| `fonts/` | Empty — see "Type" |

---

## CONTENT FUNDAMENTALS

### Voice & vibe
- **Direct, technical, no SaaS hype.** "Paste a URL. We compress it." Never "unleash" or "supercharge."
- **You-form.** Reader is the operator; the product is the equipment.
- **Verbs first.** CTAs are imperative present-tense: "Process Video", "Buy Credits", "Download PDF", "Mark This Passage."
- **Numerals always.** "10 credits", not "ten credits." "4 minutes", not "four minutes." This is broadcast voice — precise, terse.
- **Restraint on adjectives.** No "lightning-fast", no "powerful", no "intelligent." State the actual fact ("under 4 min").

### Casing
- **Headlines: Title Case** when short, **sentence case** when prose-like.
- **Buttons: Title Case** ("Process Video", "Buy Credits", "Download PDF").
- **Mono labels: UPPERCASE** with `0.14em` tracking ("RUNTIME", "PLATFORM", "CONFIDENCE 87%").
- **Status: lowercase mono** ("completed", "transcribing", "failed") — read as terminal-output, not UI badges.

### Punctuation
- **Headlines drop terminal periods**, body keeps them.
- **En-dash for ranges**, em-dash for asides — used sparingly.
- **Ellipses for live states** with three dots, no space: "Loading…", "Processing…"
- **Smart quotes** in body copy.

### Emoji
- **Banned** in chrome, captions, headlines, buttons, status. The product is precision instrumentation.
- **Tolerated** in user-content surfaces inherited from the codebase (the FAQ from `faq-accordion.tsx`).

### Specific examples — voice rewritten
- **Hero (old):** "Transform Your Videos Into Powerful Insights" → **(new):** "Turn any video into a *brief* in minutes." (italic on the one word, orange logo-bar underline beneath it)
- **Hero subhead (old):** marketing fluff → **(new):** "Paste a public URL. We download, transcribe, and structure the result into a summary, a searchable transcript, and a thematic mind map. Most videos finish in under four minutes."
- **Dashboard subhead:** unchanged — "Extract knowledge, summaries, and key takeaways from any video in minutes."
- **Wallet CTA:** "Buy Credits" — unchanged.

### Vocabulary
| Concept | Lexicon |
|---|---|
| Status | `pending`, `downloaded`, `transcribing`, `completed`, `failed` (no "in progress") |
| Platform | `YOUTUBE`, `VIMEO`, `TWITTER`, `DIRECT` (uppercased mono) |
| Time | `12:45` short, `1:42:30` long, `MM:SS` and `H:MM:SS` |
| Credits | `270 credits`, `+5 credits`, `–5 credits` (en-dash for negative) |
| Section markers | `§ 01`, `§ 02` (in mono) — paired with the logo-bars glyph |

---

## VISUAL FOUNDATIONS

### Color
- **Signal Orange `#F2A240`** (= logo play triangle) — primary action. CTAs, the play-glyph, the active-tab indicator, the underline accent under italic emphasis.
- **Insight Purple `#7E1DFD`** (= logo bars) — secondary. Section markers, link color, the bars loader, the pull-quote accent.
- **Briefing Ground `#F2F0EA`** — cool off-white workshop surface. Distinct from "paper warm" — this is monitor-side, not desk-side.
- **Ink `#0F1117`** — cool near-black for body and headlines.
- **No pastel pills.** Status uses single-dot LEDs (`.led`). Five hues only: blue/purple/orange/green/red.
- **The reel gradient `orange → magenta → purple`** is reclaimed from the original landing — but only used **once**, as a thin tape-transport bar at the top of the hero. Not on text. Not on buttons. Not anywhere else.
- **Dark mode** inverts to broadcast-monitor black `#0A0C12` + cool moon-white text. Logo purple stays the same.

### Type
- **Instrument Serif** (Google Fonts) — display, all H1/H2/H3, the italic-emphasis pattern. Defensibly distinct from Newsreader/Fraunces/EB Garamond.
- **IBM Plex Sans** — body and UI chrome. Technical neutrality, broadcast feel.
- **IBM Plex Mono** — timecodes, status labels, section numbers, ledger.
- **Italic + bar** is the signature: italic word in headline gets a 4 px orange bar underneath it (the play-triangle's stroke weight). Used at most once per surface — it earns its presence.

### Spacing
- 4 px base. App chrome at `--col-app` (1152 px). Long-form reading column at `--col-read` (608 px).

### Backgrounds
- **One ground: cool off-white.** No imagery, no patterns, no texture.
- **One gradient: the reel.** Top of hero only.
- **Header sits flush** on a hairline. No backdrop-blur, no translucency.

### Animation
See `MOTION.md`. Highlights:
- **Bars-loader replaces all spinners.**
- **60 ms stagger** is the signature.
- **No bounce on chrome.** Bounce reserved for the play-glyph on CTA press.
- **Status LED pulse** for active states only.

### Hover & press states
- **Primary CTA (orange):** hover → 8% darker. Press → 12% darker. No scale. The play-glyph nudges 2 px right on press.
- **Outline CTA (ink):** hover → fill ink, text becomes ground. Press → flatten.
- **Cards:** hover → background washes to `--bg-alt`. No shadow lift, no border-color change.
- **Disabled:** `opacity: 0.45`, `pointer-events: none`.

### Borders & radii
- **Radii:** `4 / 6 / 10 / 14` — tags, buttons, cards, modals. Status LED is full-round.
- **Borders:** 1 px hairlines. Active state → 1.5 px ink. Focus → 2 px orange offset 2 px.

### Shadows
- **No card shadows.** Cards have a 1 px hairline border and a faint inset top edge (`--face-light`) to feel like printed matter, not floating chrome.
- **Modals only** use `--shadow-modal` — a deep, soft cool shadow.

### Cards — the **Index Card** pattern

```
┌──┬──────────────────────────────────────┐
│  │ § 02 · YOUTUBE · 12:45      JUL 30   │  ← mono header on hairline
│ █│──────────────────────────────────────│
│ █│                                      │
│ █│ How to Build a SaaS Application      │  ← Instrument Serif title
│ █│                                      │
│  │──────────────────────────────────────│
│  │ 12 insights · 5 topics    ● completed│  ← mono meta + LED
└──┴──────────────────────────────────────┘
   ↑ 6 px tape-label tab in status color
```

- 10 px radius
- 1 px hairline border
- A **6 px-wide left column** in the **status color** runs floor-to-ceiling on the left edge — the "tape-label tab." Status is visible at a glance even without reading the LED.
- Two horizontal hairlines divide three zones: meta / title / footer
- Inner padding 16–20 px

### Iconography
See ICONOGRAPHY section.

---

## ICONOGRAPHY

### Strategy
- **Hugeicons Free (line)** stays as the production icon set, imported via `@hugeicons/react`. Stroke 1.5 px monochrome. Used in JSX UI-kit components.
- **Lucide Static (CDN)** in standalone HTML preview cards — closest visual cousin. Both are 1.5 px monochrome line.
- **Custom logo-bar glyph** (`.logo-bars`) replaces icons in section markers, loaders, and the pull-quote accent — because no off-the-shelf icon expresses the product's brand mark.

### Brand SVGs
Platform marks (YouTube/Vimeo/Twitter) keep their brand colors as inline SVGs. Everything else is monochrome ink.

### Sizing
- 14 px inline-with-text · 18 px chrome · 22 px nav · 32 px feature mark
- **Never color-fill icons** except platform marks and the play-glyph on CTAs.

### Emoji & Unicode
- Emoji **forbidden** in chrome.
- `§` glyph permitted for section numbering (`§ 01`).
- `·` middle dot for inline meta separators.
- `→` for "next step" micro-copy in CTAs.

---

## File index (manifest)

```
SummaryVideos Design System/
├── README.md                       ← you are here
├── MOTION.md                       ← motion spec, principles, scenes
├── SKILL.md                        ← Claude Code skill manifest
├── colors_and_type.css             ← all tokens — @import this
├── assets/
│   └── summary_videos_logo.png
├── preview/                        ← preview cards rendered on the DS tab
│   ├── logo.html
│   ├── colors-ground-ink.html
│   ├── colors-logo-dna.html
│   ├── colors-status-leds.html
│   ├── type-display.html
│   ├── type-body.html
│   ├── type-mono.html
│   ├── type-italic-bar.html
│   ├── spacing.html
│   ├── radii-borders.html
│   ├── motion-bars-loader.html
│   ├── motion-led-pulse.html
│   ├── buttons.html
│   ├── inputs.html
│   ├── status-leds.html
│   ├── index-card.html
│   ├── header.html
│   ├── meta-row.html
│   ├── pull-quote.html
│   ├── section-markers.html
│   └── iconography.html
└── ui_kits/
    └── web-app/
        ├── README.md
        ├── index.html              ← interactive click-through
        ├── styles.css
        ├── Header.jsx
        ├── Landing.jsx
        ├── AuthDialog.jsx
        ├── Dashboard.jsx
        ├── SubmissionCard.jsx
        ├── SubmissionDetail.jsx
        └── Wallet.jsx
```

---

## Known gaps & flags

- **Fonts loaded via Google Fonts CDN.** For offline use, drop `.woff2` into `fonts/` and `@font-face` over them. Inter (from the original product) is preserved as a system fallback.
- **Hugeicons has no SVG CDN.** Static HTML previews substitute Lucide. UI-kit React imports Hugeicons directly so the live recreations remain pixel-faithful.
- **No marketing surfaces beyond landing** in the source (no docs, blog, pricing). UI kit covers what exists.
- **No Figma was attached.** All visual decisions are extracted from the React source + the logo + the user's directional feedback.
- **The reel gradient (orange → magenta → purple) is preserved as `--reel-gradient`** but used only once — as a thin tape-transport bar at the top of the hero. Resist the temptation to apply it to text, buttons, or cards.
