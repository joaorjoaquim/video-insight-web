---
name: summaryvideos-design
description: Use this skill to generate well-branded interfaces and assets for SummaryVideos, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. SummaryVideos is a video-to-brief tool with an editorial "Briefing Room" visual identity anchored on the orange play triangle and purple bars of its logo.
user-invocable: true
---

# SummaryVideos Design

Read the README.md file within this skill, and explore the other available files (MOTION.md is essential; colors_and_type.css holds the tokens you import; ui_kits/web-app/ has working JSX components).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out of `assets/` and create static HTML files for the user to view. Import `colors_and_type.css` for tokens — the whole system descends from it. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

## The non-negotiables

Before drawing anything, internalize these. They are what makes this system *this* system and not generic AI SaaS:

1. **Orange is action. Purple is insight.** The two anchor colors are lifted directly from the logo — the play triangle and the bars. Use them with intent. Don't mix them into a gradient (except the single hero `--reel-gradient`). Don't use them decoratively.

2. **The logo's bars are the section marker.** Three short purple bars of decreasing width (`.logo-bars`) appear before every page H1 and every section heading. They are not optional decoration — they ARE the section glyph.

3. **The logo's play triangle is the CTA glyph.** Every primary CTA button has a `.play-glyph` (a CSS-clip triangle) inline. Buttons read as "play → start".

4. **Italic + orange bar = emphasis.** One word per headline gets `<span class="ital-bar">word</span>` — italic Instrument Serif with a 4 px orange underline. Use exactly once per surface; it earns its presence.

5. **No spinners. Use the bars loader.** The product's loading state IS the logo bars filling in left-to-right with stagger (`.bars-loader`). Spinners imply unknown duration; bars imply structured work.

6. **No pastel pills.** Status is a small filled dot (the broadcast LED) + lowercase mono label (`.led.transcribing`, `.led.completed`, etc).

7. **No card shadows.** Cards have hairline borders and an inset 1 px top edge. Status visibility comes from the **tape-label tab** — a 6 px-wide colored strip down the left edge of each card.

8. **Type pairing:** Instrument Serif (display) + IBM Plex Sans (UI) + IBM Plex Mono (timecodes, status, ledger). Do not substitute Inter/Roboto/Newsreader without a real reason.

9. **Ground is cool off-white** (`#F2F0EA`), not paper-warm. The product is monitor-side, not desk-side.

10. **The reel gradient (`orange → magenta → purple`) is used exactly once per page max** — as a thin tape-transport bar at the top of the hero. Not on text, not on buttons, not on cards.

## Workflow

If the user invokes this skill without other guidance, ask them what they want to build or design. Then act as an expert designer who outputs HTML artifacts *or* production code, depending on the need.

A good question set to ask:
- Are we designing for the **marketing surface** (landing-page register, large Instrument Serif, animated hero) or the **authed workshop** (denser, mono-meta, index-card register)?
- Do you want **light or dark mode** (the system supports both natively)?
- Do you have **placeholder content** you want to drop in, or should we use canonical sample data from `ui_kits/web-app/`?

## Files reference

- `colors_and_type.css` — all design tokens (`--play`, `--bars`, `--bg`, `--fg-1`, `--font-display`, etc.). Import this first.
- `README.md` — manifesto, content fundamentals, visual foundations, iconography.
- `MOTION.md` — motion principles, duration/easing tokens, and 10 named scenes.
- `assets/summary_videos_logo.png` — the canonical logo. Use as-is.
- `ui_kits/web-app/` — working JSX components: `Header`, `Landing`, `Dashboard`, `SubmissionCard`, `SubmissionDetail`, `Wallet`, `AuthDialog`. Plus `styles.css` (the kit-level component CSS). Crib heavily.
- `preview/*.html` — small standalone preview cards you can read to see how individual tokens render.
