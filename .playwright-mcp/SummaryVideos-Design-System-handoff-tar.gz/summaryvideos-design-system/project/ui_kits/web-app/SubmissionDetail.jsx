// SubmissionDetail.jsx — single result page with Summary / Transcript / Insights tabs
function SubmissionDetail({ submission, onBack }) {
  const s = submission;
  const [tab, setTab] = React.useState('summary');
  const [insightView, setInsightView] = React.useState('list');

  // Split last 2 words for the italic-bar emphasis
  const parts = s.title.split(' ');
  const titleLead = parts.slice(0, -2).join(' ');
  const titleTail = parts.slice(-2).join(' ');

  return (
    <main className="container" style={{paddingTop: 32, paddingBottom: 120, maxWidth: 1024}}>
      <button onClick={onBack} style={{background: 'transparent', border: 0, cursor: 'pointer', padding: 0, marginBottom: 32}}>
        <span className="meta" style={{color: 'var(--fg-2)'}}>← BACK TO DASHBOARD</span>
      </button>

      {/* TITLE BLOCK */}
      <section style={{paddingBottom: 32, borderBottom: '1px solid var(--rule)'}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18}}>
          <span className="logo-bars lg"><i/><i/><i/></span>
          <span style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--fg-3)', fontWeight: 500}}>§ 02 — ANALYSIS COMPLETE</span>
        </div>
        <h1 className="display-1" style={{maxWidth: '20ch', marginBottom: 28, fontSize: 'clamp(2.5rem, 4.5vw + 1rem, 4.5rem)'}}>
          {titleLead}{titleLead && ' '}<span className="ital-bar">{titleTail}</span>
        </h1>
        <div className="meta" style={{display: 'flex', flexWrap: 'wrap', gap: '0 16px', alignItems: 'center'}}>
          <span>{s.platform}</span>
          <span style={{color: 'var(--rule)'}}>·</span>
          <span>RUNTIME {s.duration}</span>
          <span style={{color: 'var(--rule)'}}>·</span>
          <span>SUBMITTED {s.dateLong || s.dateShort}</span>
          <span style={{color: 'var(--rule)'}}>·</span>
          <span className="led completed">completed</span>
        </div>
      </section>

      {/* TABS */}
      <div className="tabs" style={{marginTop: 32}}>
        <button className={'tab ' + (tab === 'summary' ? 'active' : '')} onClick={() => setTab('summary')}>Summary</button>
        <button className={'tab ' + (tab === 'transcript' ? 'active' : '')} onClick={() => setTab('transcript')}>Transcript</button>
        <button className={'tab ' + (tab === 'insights' ? 'active' : '')} onClick={() => setTab('insights')}>Insights</button>
      </div>

      {tab === 'summary' && <SummaryView s={s} />}
      {tab === 'transcript' && <TranscriptView s={s} />}
      {tab === 'insights' && <InsightsView s={s} view={insightView} setView={setInsightView} />}
    </main>
  );
}

function ActionRow() {
  return (
    <div style={{display: 'flex', gap: 4, justifyContent: 'flex-end'}}>
      <button className="btn btn-ghost btn-sm" title="Download PDF">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
        Download PDF
      </button>
      <button className="btn btn-ghost btn-sm" title="Copy">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
        Copy
      </button>
      <button className="btn btn-ghost btn-sm" title="Share">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.59 13.51l6.83 3.98M15.41 6.51l-6.82 3.98"/></svg>
        Share
      </button>
    </div>
  );
}

function SummaryView({ s }) {
  return (
    <div style={{display: 'grid', gridTemplateColumns: '1fr 280px', gap: 56, marginTop: 16}}>
      <article>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18}}>
          <div className="eyebrow">§ Summary</div>
          <ActionRow />
        </div>
        <div className="drop-cap" style={{maxWidth: '38rem'}}>
          <p style={{fontSize: 17, lineHeight: 1.65, color: 'var(--fg-1)', marginBottom: '1.25em'}}>
            This video provides a comprehensive guide to building a SaaS application from scratch. The presenter covers everything from initial planning and architecture to deployment and scaling — with concrete examples drawn from production code shipped over the past two years.
          </p>
          <p style={{fontSize: 17, lineHeight: 1.65, color: 'var(--fg-1)', marginBottom: '1.25em'}}>
            Key areas covered include choosing the right tech stack for different types of SaaS applications, implementing authentication and authorization systems, setting up payment processing with Stripe, and designing database schemas that can scale with your business as it grows.
          </p>
          <p style={{fontSize: 17, lineHeight: 1.65, color: 'var(--fg-1)'}}>
            The presenter emphasizes the importance of starting with a minimum viable product and iterating based on user feedback. They demonstrate how to set up a continuous integration and deployment pipeline to streamline the development process.
          </p>
        </div>

        <div className="pull-quote" style={{marginTop: 40}}>
          <div className="body">"Always implement role-based access control from day one."</div>
        </div>
        <div className="meta" style={{marginTop: 10, marginLeft: 50}}>EXTRACTED · TC 05:32 · CONFIDENCE 94%</div>
      </article>
      <aside>
        <div className="eyebrow" style={{marginBottom: 16}}>Metadata</div>
        <div style={{borderTop: '1px solid var(--rule)'}}>
          {[['Runtime', s.duration, false], ['Topics', '5', false], ['Insights', '12', false], ['Complexity', 'Intermediate', true]].map(([k, v, ital], i) => (
            <div key={i} style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '14px 0', borderBottom: '1px solid var(--rule-soft)'}}>
              <span className="meta">{k}</span>
              <span style={{fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 400, color: ital ? 'var(--play)' : 'var(--fg-1)', fontStyle: ital ? 'italic' : 'normal', letterSpacing: '-0.012em'}}>{v}</span>
            </div>
          ))}
        </div>
        <div className="eyebrow" style={{marginTop: 32, marginBottom: 14}}>Topics</div>
        <div style={{display: 'flex', flexWrap: 'wrap', gap: 6}}>
          {TOPICS.map((t, i) => (
            <span key={i} style={{fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--fg-2)', border: '1px solid var(--rule)', padding: '4px 8px', borderRadius: 4}}>{t}</span>
          ))}
        </div>
      </aside>
    </div>
  );
}

function TranscriptView({ s }) {
  return (
    <div style={{marginTop: 16}}>
      <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24}}>
        <div className="eyebrow">§ Transcript · {TRANSCRIPT.length} segments</div>
        <ActionRow />
      </div>
      <div style={{maxWidth: 720}}>
        {TRANSCRIPT.map((t, i) => (
          <div key={i} className="transcript-row">
            <div><span className="transcript-time">{t.time}</span></div>
            <div className="transcript-text">{t.text}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function InsightsView({ s, view, setView }) {
  return (
    <div style={{marginTop: 16}}>
      <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24}}>
        <div style={{display: 'inline-flex', border: '1px solid var(--rule)', borderRadius: 6, overflow: 'hidden'}}>
          {['list', 'mindmap'].map(v => (
            <button key={v} onClick={() => setView(v)}
              style={{padding: '8px 16px', border: 0, background: view === v ? 'var(--ink-1)' : 'transparent', color: view === v ? 'var(--bg)' : 'var(--fg-2)', fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.1em', textTransform: 'uppercase', cursor: 'pointer', fontWeight: 500}}>
              {v === 'list' ? 'LIST' : 'MIND MAP'}
            </button>
          ))}
        </div>
        <ActionRow />
      </div>

      {view === 'list' && (
        <div style={{maxWidth: 800}}>
          <div style={{display: 'flex', gap: 8, marginBottom: 28, flexWrap: 'wrap'}}>
            {[['12 INSIGHTS', false], ['5 TOPICS', false], ['3 KEY TAKEAWAYS', true], ['CONFIDENCE 87%', false]].map(([label, accent], i) => (
              <span key={i} style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.08em', color: accent ? 'var(--play)' : 'var(--fg-2)', border: '1px solid ' + (accent ? 'var(--play)' : 'var(--rule)'), padding: '3px 9px', borderRadius: 4}}>{label}</span>
            ))}
          </div>
          {INSIGHTS.map((sect, i) => (
            <section key={i} className="insight-section">
              <div className="insight-head">
                <span className="logo-bars"><i/><i/><i/></span>
                <span style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--play-700)', fontWeight: 500}}>0{i + 1}</span>
                <h3 style={{fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 400, letterSpacing: '-0.012em', margin: 0}}>{sect.title}</h3>
              </div>
              <div style={{marginLeft: 38}}>
                {sect.items.map((it, j) => (
                  <div key={j} className="insight-item">
                    <div>{it.confidence && <span className="insight-conf">{it.confidence}%</span>}</div>
                    <div>
                      {it.key && <span className="insight-key">Key</span>}
                      {it.quote
                        ? <div className="pull-quote" style={{marginTop: 4}}><div className="body" style={{fontSize: 19}}>{it.text}</div></div>
                        : <span style={{fontSize: 15, lineHeight: 1.6, color: 'var(--fg-1)'}}>{it.text}</span>}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      {view === 'mindmap' && (
        <div className="mindmap">
          <div className="mindmap-node root">Video Insights</div>
          <div className="mindmap-rule"></div>
          <div className="mindmap-row">
            {MIND_MAP.map((b, i) => (
              <div key={i} className="mindmap-col">
                <div className="mindmap-node branch">{b.label}</div>
                <div className="mindmap-rule"></div>
                <div className="mindmap-row" style={{flexDirection: 'column', alignItems: 'center', gap: 6}}>
                  {b.children.map((c, j) => (
                    <div key={j} className="mindmap-node leaf">{c}</div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

const TOPICS = ['TECH STACK', 'AUTH', 'PAYMENTS', 'DATABASE', 'DEPLOYMENT'];

const TRANSCRIPT = [
  { time: '00:00', text: 'Welcome to the SaaS application course. Today we are going to walk through everything you need to ship a real product.' },
  { time: '01:15', text: 'Let us start with planning and architecture. The single most important decision is the boundary of your first release.' },
  { time: '03:30', text: "Choosing the right tech stack is crucial — but pick it based on your team's expertise, not the discourse on Twitter." },
  { time: '05:00', text: "Now we get into authentication and authorization. We'll set up email-and-password plus OAuth in under twenty minutes." },
  { time: '08:20', text: 'Setting up payment processing with Stripe. Subscription, usage-based, and one-time charges — all of it.' },
  { time: '10:00', text: 'Designing scalable database schemas. Multi-tenant from day one, or single-tenant with a migration plan.' },
  { time: '12:00', text: 'Continuous integration and deployment. CI is the boring infrastructure that pays for itself in the second month.' },
];

const INSIGHTS = [
  { title: 'Tech Stack Selection', items: [
    { text: 'Frontend frameworks like React, Vue, or Angular are ideal for SaaS UIs.', confidence: 95 },
    { text: 'Node.js and Express are recommended for backend API development.', confidence: 92 },
    { text: 'Choose your tech stack based on team expertise rather than trends.', key: true },
  ]},
  { title: 'Authentication & Authorization', items: [
    { text: 'OAuth 2.0 is recommended for secure third-party authentication.', confidence: 88 },
    { text: 'JWT tokens provide stateless authentication for scalable applications.', confidence: 90 },
    { text: '"Always implement role-based access control from day one."', quote: true },
  ]},
  { title: 'Payment Processing', items: [
    { text: 'Stripe is recommended for subscription management and payment processing.', confidence: 94 },
    { text: 'Implement usage-based billing for better customer value alignment.', key: true },
  ]},
];

const MIND_MAP = [
  { label: 'Tech Stack', children: ['React', 'Node', 'Postgres'] },
  { label: 'Auth', children: ['OAuth', 'JWT', 'RBAC'] },
  { label: 'Payments', children: ['Stripe', 'Usage-based'] },
  { label: 'Database', children: ['Multi-tenant', 'Migrations'] },
];

window.SubmissionDetail = SubmissionDetail;
