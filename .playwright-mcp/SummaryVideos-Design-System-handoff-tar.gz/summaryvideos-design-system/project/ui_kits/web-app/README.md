# SummaryVideos · Web App UI Kit

A high-fidelity, click-through prototype of the SummaryVideos product, rebuilt in the **Briefing Room** design system. Open `index.html` to interact.

## What's in here

| File | What it is |
|---|---|
| `index.html` | App shell + state. Wires every screen together. Open this. |
| `styles.css` | Kit-level CSS that imports the system tokens. |
| `Header.jsx` | Sticky paper header with mono nav, orange-underline on active, wallet inline. Switches between auth/unauth states. |
| `Landing.jsx` | Unauthenticated marketing page — hero, four-artefact feature stack, credit packages, three-step "how it works", closer. |
| `AuthDialog.jsx` | Sign-in / sign-up modal — underline labels, OAuth (Google + Discord), play-glyph CTA. |
| `Dashboard.jsx` | Authed home — URL composer + 3-column submission grid + FAQ. |
| `SubmissionCard.jsx` | The index-card pattern — tape-label tab in status color, mono metadata header, Instrument Serif title, LED footer. |
| `SubmissionDetail.jsx` | Single-result page — Summary / Transcript / Insights tabs, pull-quote, mind-map. |
| `Wallet.jsx` | Credit balance, transaction ledger, buy-credits dialog with package tiles. |

## Interactive flow

1. Land on **Landing** as unauthed. Click any "Get Started" / "Sign In" → opens **AuthDialog**.
2. Submit any email/password (or click Google/Discord) → flips to authed, drops you on **Dashboard**.
3. Dashboard auto-progresses any `transcribing` submissions in real time (+1% per ~600 ms). When one hits 100%, it flips to `completed`.
4. Paste a URL into the composer → creates a new submission card. 5 credits are deducted.
5. Click any `completed` card → opens **SubmissionDetail** (Summary tab default; switch to Transcript or Insights → List or Mind Map).
6. Click "Wallet" in the nav → **Wallet**. Click "Buy Credits" → 4-package modal. Confirm → balance animates up.

## Fidelity notes

- **Real component coverage**, not pixel-replicas of the original product. Visual treatment is the new system; behavior and copy mirror what's in `video-insight-web/`.
- Status polling, queue progression, and balance changes are all faked client-side.
- Search/filter on the dashboard works against the local data set.
- Mind-map is a static tree visualization, not interactive.
- No real auth, no real API calls. Submitting always "succeeds".

## Visiting the kit

Open `index.html` directly. Designed for desktop ≥ 1024 px (the live product is responsive; the kit isn't optimised below tablet).
