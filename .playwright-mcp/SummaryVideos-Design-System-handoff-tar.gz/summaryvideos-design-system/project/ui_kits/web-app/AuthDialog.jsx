// AuthDialog.jsx — modal sign in / sign up
function AuthDialog({ open, mode = 'login', onClose, onSubmit, onSwitchMode }) {
  if (!open) return null;
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const handleSubmit = (e) => { e.preventDefault(); onSubmit({ email, password }); };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose} aria-label="Close">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>

        <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14}}>
          <span className="logo-bars"><i/><i/><i/></span>
          <span style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--fg-3)', fontWeight: 500}}>§ {mode === 'login' ? 'SIGN IN' : 'GET STARTED'}</span>
        </div>
        <h3 className="display-3" style={{marginBottom: 6}}>
          {mode === 'login' ? <>Welcome <span className="ital-bar">back</span>.</> : <>Get <span className="ital-bar">started</span>.</>}
        </h3>
        <p className="meta" style={{marginBottom: 24}}>
          {mode === 'login' ? 'Sign in to continue.' : 'New here? 100 free credits on the house.'}
        </p>

        <form className="auth-form" onSubmit={handleSubmit}>
          <div>
            <label>Email</label>
            <input className="field" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com"/>
          </div>
          <div>
            <label>Password</label>
            <input className="field" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••"/>
          </div>
          <button type="submit" className="btn btn-primary" style={{justifyContent: 'center', marginTop: 8}}>
            {mode === 'login' ? 'Sign In' : 'Sign Up'} <span className="play-glyph"></span>
          </button>
        </form>

        <div className="auth-split"><span>OR</span></div>

        <div className="oauth-grid">
          <button className="oauth-btn" onClick={() => onSubmit({ provider: 'google' })}>
            <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Google
          </button>
          <button className="oauth-btn" onClick={() => onSubmit({ provider: 'discord' })}>
            <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#5865F2" d="M20.317 4.37a19.79 19.79 0 0 0-4.885-1.515.074.074 0 0 0-.078.037c-.211.375-.445.864-.608 1.249a18.27 18.27 0 0 0-5.487 0 12.6 12.6 0 0 0-.617-1.249.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.319 13.58.099 18.058a.082.082 0 0 0 .031.056 19.9 19.9 0 0 0 5.993 3.03.077.077 0 0 0 .084-.028c.462-.63.873-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.1 13.1 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.291a.074.074 0 0 1 .078-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .079.01c.12.099.246.198.372.292a.077.077 0 0 1-.006.128c-.598.349-1.22.645-1.873.891a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.84 19.84 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.06.06 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.095 2.157 2.42 0 1.333-.955 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.095 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>
            Discord
          </button>
        </div>

        <div style={{textAlign: 'center', marginTop: 24}}>
          <a onClick={onSwitchMode} style={{cursor: 'pointer', fontSize: 13}}>
            {mode === 'login' ? "Don't have an account? Sign up." : 'Already have an account? Sign in.'}
          </a>
        </div>
      </div>
    </div>
  );
}

window.AuthDialog = AuthDialog;
