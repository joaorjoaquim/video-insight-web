// Wallet.jsx — balance + transaction history + buy-credits dialog
function Wallet({ credits = 270, onBuy }) {
  const [open, setOpen] = React.useState(false);
  const [selected, setSelected] = React.useState('popular');
  const [filterType, setFilterType] = React.useState('all');
  const [filterPeriod, setFilterPeriod] = React.useState('30days');

  const totalPurchased = 600;
  const totalUsed = 330;

  const txns = TRANSACTIONS.filter(t => {
    if (filterType !== 'all' && t.type !== filterType) return false;
    if (filterPeriod === '30days') {
      const cutoff = new Date('2026-04-19');
      if (new Date(t.dateIso) < cutoff) return false;
    }
    return true;
  });

  return (
    <main className="container" style={{paddingTop: 56, paddingBottom: 120, maxWidth: 1024}}>
      {/* HERO */}
      <section style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32, marginBottom: 56}}>
        <SectionMark n="01" label="Balance" stacked />
        <div>
          <div className="eyebrow" style={{marginBottom: 18}}>Current balance</div>
          <div className="balance-num" style={{marginBottom: 14}}>
            {credits}<span className="units">credits</span>
          </div>
          <div className="meta" style={{marginBottom: 28}}>
            LAST TRANSACTION · MAY 19 2026 · ~{Math.round(credits / 6)} VIDEOS LEFT
          </div>
          <button className="btn btn-primary" onClick={() => setOpen(true)}>
            Buy Credits <span className="play-glyph"></span>
          </button>

          <div style={{display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 32, marginTop: 56, paddingTop: 32, borderTop: '1px solid var(--rule)'}}>
            <Stat label="Total purchased" value={totalPurchased} />
            <Stat label="Total used" value={totalUsed} />
            <Stat label="Current balance" value={credits} accent />
          </div>
        </div>
      </section>

      <hr className="rule" />

      {/* TRANSACTIONS */}
      <section style={{paddingTop: 56}}>
        <div style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32}}>
          <SectionMark n="02" label="Ledger" stacked />
          <div>
            <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24, gap: 16, flexWrap: 'wrap'}}>
              <h2 className="display-3">Transaction history</h2>
              <div style={{display: 'flex', gap: 10}}>
                <select className="select" value={filterType} onChange={(e) => setFilterType(e.target.value)}>
                  <option value="all">ALL TYPES</option>
                  <option value="spend">SPENT</option>
                  <option value="purchase">PURCHASED</option>
                  <option value="refund">REFUNDED</option>
                </select>
                <select className="select" value={filterPeriod} onChange={(e) => setFilterPeriod(e.target.value)}>
                  <option value="all">ALL TIME</option>
                  <option value="30days">LAST 30 DAYS</option>
                </select>
              </div>
            </div>

            <table className="tbl">
              <thead>
                <tr>
                  <th style={{width: 100}}>Type</th>
                  <th>Description</th>
                  <th style={{width: 140, textAlign: 'right'}}>Amount</th>
                  <th style={{width: 110, textAlign: 'right'}}>Status</th>
                </tr>
              </thead>
              <tbody>
                {txns.map((t, i) => (
                  <tr key={i}>
                    <td>
                      <span className="meta" style={{fontSize: 10, color: t.amount >= 0 ? 'var(--led-completed)' : 'var(--play-700)'}}>
                        {t.type.toUpperCase()}
                      </span>
                    </td>
                    <td>
                      <div style={{fontSize: 14, color: 'var(--fg-1)'}}>{t.description}</div>
                      <div className="meta" style={{fontSize: 10, marginTop: 2}}>{t.dateLong}</div>
                    </td>
                    <td style={{textAlign: 'right', fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: 500, color: t.amount >= 0 ? 'var(--led-completed)' : 'var(--play-700)'}}>
                      {t.amount >= 0 ? '+' : '–'}{Math.abs(t.amount)} credits
                    </td>
                    <td style={{textAlign: 'right'}}>
                      <span className="led completed">completed</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="meta" style={{marginTop: 16}}>
              SHOWING {txns.length} OF {TRANSACTIONS.length} TRANSACTIONS
            </div>
          </div>
        </div>
      </section>

      {open && (
        <BuyCreditsDialog
          selected={selected}
          setSelected={setSelected}
          onClose={() => setOpen(false)}
          onConfirm={() => { onBuy && onBuy(selected); setOpen(false); }}
        />
      )}
    </main>
  );
}

function SectionMark({ n, label, stacked }) {
  if (!stacked) return null;
  return (
    <div>
      <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8}}>
        <span className="logo-bars"><i/><i/><i/></span>
        <span style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--fg-3)', fontWeight: 500}}>§ {n}</span>
      </div>
      <div style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--fg-2)', fontWeight: 500}}>{label}</div>
    </div>
  );
}

function Stat({ label, value, accent }) {
  return (
    <div>
      <div className="eyebrow" style={{marginBottom: 8}}>{label}</div>
      <div style={{fontFamily: 'var(--font-display)', fontSize: 44, fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1, color: accent ? 'var(--play)' : 'var(--fg-1)', fontStyle: accent ? 'italic' : 'normal'}}>
        {value}
      </div>
      <div className="meta" style={{marginTop: 4, fontSize: 10}}>credits</div>
    </div>
  );
}

function BuyCreditsDialog({ selected, setSelected, onClose, onConfirm }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal modal-wide" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose} aria-label="Close">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M18 6L6 18M6 6l12 12"/></svg>
        </button>
        <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14}}>
          <span className="logo-bars"><i/><i/><i/></span>
          <span style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--fg-3)', fontWeight: 500}}>§ TOP UP</span>
        </div>
        <h3 className="display-3" style={{marginBottom: 8}}>Credit <span className="ital-bar">packages</span>.</h3>
        <p className="meta" style={{marginBottom: 28}}>Buy once. Use whenever. No subscriptions.</p>

        <div className="stagger-list" style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 28}}>
          {PACKAGES_FULL.map((p) => (
            <button
              key={p.id}
              className={'pkg ' + (selected === p.id ? 'selected ' : '') + (p.recommended ? 'recommended' : '')}
              onClick={() => setSelected(p.id)}>
              <div className="eyebrow">{p.name}</div>
              <div className="pkg-amt">{p.amount} <small>credits</small></div>
              <div className="pkg-per">${p.per.toFixed(2)} PER CREDIT</div>
              <div style={{marginTop: 'auto', paddingTop: 8, borderTop: '1px solid var(--rule-soft)'}}>
                <div className="pkg-price">${p.price.toFixed(2)}</div>
              </div>
            </button>
          ))}
        </div>

        <button className="btn btn-primary" style={{width: '100%', justifyContent: 'center'}} onClick={onConfirm}>
          Buy Now <span className="play-glyph"></span>
        </button>
      </div>
    </div>
  );
}

const PACKAGES_FULL = [
  { id: 'starter',    name: 'STARTER',    amount: 10,  price: 9.90,  per: 0.99 },
  { id: 'popular',    name: 'POPULAR',    amount: 25,  price: 19.75, per: 0.79, recommended: true },
  { id: 'pro',        name: 'PRO',        amount: 50,  price: 34.50, per: 0.69 },
  { id: 'enterprise', name: 'ENTERPRISE', amount: 100, price: 59.00, per: 0.59 },
];

const TRANSACTIONS = [
  { type: 'refund',   amount:  5,  description: 'Refund — failed video download', dateLong: 'May 19, 2026',  dateIso: '2026-05-19' },
  { type: 'refund',   amount:  5,  description: 'Refund — failed video download', dateLong: 'May 19, 2026',  dateIso: '2026-05-19' },
  { type: 'spend',    amount: -5,  description: 'Video submission · How to Build a SaaS Application', dateLong: 'May 19, 2026', dateIso: '2026-05-19' },
  { type: 'refund',   amount:  5,  description: 'Refund — failed video download', dateLong: 'May 5, 2026',   dateIso: '2026-05-05' },
  { type: 'spend',    amount: -8,  description: 'Video submission · The Future of Web Development', dateLong: 'May 5, 2026', dateIso: '2026-05-05' },
  { type: 'purchase', amount:  25, description: 'Popular package purchase',        dateLong: 'May 1, 2026',   dateIso: '2026-05-01' },
  { type: 'spend',    amount: -12, description: 'Video submission · CI/CD pipeline deep-dive', dateLong: 'Apr 28, 2026', dateIso: '2026-04-28' },
];

window.Wallet = Wallet;
