// Dashboard.jsx — authed home: paste-a-URL composer + submission grid + FAQ
function Dashboard({ submissions, onOpen, onSubmitUrl }) {
  const [url, setUrl] = React.useState('');
  const [status, setStatus] = React.useState('all');
  const [search, setSearch] = React.useState('');

  const filtered = submissions.filter(s =>
    (status === 'all' || s.status === status) &&
    s.title.toLowerCase().includes(search.toLowerCase())
  );

  const onSubmit = (e) => {
    e.preventDefault();
    if (!url.trim()) return;
    onSubmitUrl(url.trim());
    setUrl('');
  };

  return (
    <main className="container" style={{paddingTop: 56, paddingBottom: 120}}>
      {/* HERO + COMPOSER */}
      <section style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32, marginBottom: 56}}>
        <SectionMark n="01" label="Submit a video" stacked />
        <div>
          <h1 className="display-2" style={{maxWidth: '18ch', marginBottom: 14}}>
            Turn any video into <span className="ital-bar">instant</span> insight.
          </h1>
          <p className="lead" style={{marginBottom: 28}}>
            Extract knowledge, summaries, and key takeaways from any video in minutes.
          </p>

          <form onSubmit={onSubmit} className="composer">
            <label className="eyebrow" htmlFor="video-url" style={{display: 'block', marginBottom: 10}}>
              Paste a URL — YouTube · Vimeo · Twitter · Direct
            </label>
            <div className="composer-row">
              <input
                id="video-url" className="field" value={url} onChange={(e) => setUrl(e.target.value)}
                placeholder="https://youtube.com/watch?v=…" style={{flex: 1}}
              />
              <button type="submit" className="btn btn-primary">
                Submit <span className="play-glyph"></span>
              </button>
            </div>
            <div className="meta" style={{marginTop: 14}}>
              5–15 CREDITS PER VIDEO · 2-HOUR MAX · CREDITS REFUNDED ON FAILURE
            </div>
          </form>
        </div>
      </section>

      <hr className="rule" />

      {/* SUBMISSIONS */}
      <section style={{paddingTop: 56}}>
        <div style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32, marginBottom: 28}}>
          <SectionMark n="02" label="Recent" stacked />
          <div style={{display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 24, flexWrap: 'wrap'}}>
            <div>
              <h2 className="display-3" style={{marginBottom: 6}}>Recent submissions</h2>
              <p className="meta" style={{margin: 0}}>{filtered.length} OF {submissions.length} JOBS</p>
            </div>
            <div style={{display: 'flex', gap: 10}}>
              <select className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="all">ALL STATUSES</option>
                <option value="completed">COMPLETED</option>
                <option value="transcribing">TRANSCRIBING</option>
                <option value="pending">PENDING</option>
                <option value="failed">FAILED</option>
              </select>
              <input className="field" placeholder="Search…" value={search} onChange={(e) => setSearch(e.target.value)} style={{maxWidth: 240, fontSize: 14, padding: '9px 14px'}} />
            </div>
          </div>
        </div>

        <div className="stagger-list" style={{display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18}}>
          {filtered.map((s, i) => (
            <SubmissionCard key={s.id} submission={s} index={i} onOpen={onOpen} />
          ))}
          {filtered.length === 0 && (
            <div style={{gridColumn: '1 / -1', textAlign: 'center', padding: 56, border: '1px dashed var(--rule)', borderRadius: 10, color: 'var(--fg-3)'}}>
              <div className="meta" style={{marginBottom: 8}}>NO MATCHING SUBMISSIONS</div>
              <div className="display-3">Paste a URL to begin.</div>
            </div>
          )}
        </div>
      </section>

      {/* FAQ */}
      <section style={{paddingTop: 96}}>
        <div style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32, marginBottom: 28}}>
          <SectionMark n="03" label="FAQ" stacked />
          <div>
            <h2 className="display-3">Common questions</h2>
            <div style={{marginTop: 24, borderTop: '1px solid var(--rule)'}}>
              {FAQS.map((q, i) => <FAQItem key={i} {...q} />)}
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

function SectionMark({ n, label, stacked }) {
  if (stacked) {
    return (
      <div>
        <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8}}>
          <span className="logo-bars"><i/><i/><i/></span>
          <span style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--fg-3)', fontWeight: 500}}>§ {n}</span>
        </div>
        <div style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--fg-2)', fontWeight: 500}}>{label}</div>
      </div>
    );
  }
  return null;
}

function FAQItem({ q, a }) {
  const [open, setOpen] = React.useState(false);
  return (
    <div style={{borderBottom: '1px solid var(--rule)'}}>
      <button onClick={() => setOpen(!open)} style={{width: '100%', padding: '20px 0', background: 'transparent', border: 0, cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', textAlign: 'left'}}>
        <span style={{fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 400, color: 'var(--fg-1)', letterSpacing: '-0.012em'}}>{q}</span>
        <span style={{fontFamily: 'var(--font-mono)', fontSize: 14, color: 'var(--play)'}}>{open ? '–' : '+'}</span>
      </button>
      {open && (
        <div style={{paddingBottom: 24, color: 'var(--fg-2)', fontSize: 15, lineHeight: 1.65, maxWidth: '40rem'}}>
          {a}
        </div>
      )}
    </div>
  );
}

const FAQS = [
  { q: 'How does SummaryVideos work?',
    a: 'Paste a public video URL. We download it, transcribe and analyse it with advanced language models, and return a summary, time-stamped transcript, insights, and a mind map. Average processing time is 2–5 minutes.' },
  { q: 'What videos can I analyse?',
    a: 'Anything public on YouTube, Vimeo, Twitter, or a direct hosted link. Two-hour ceiling per video. Restricted or private videos are not supported.' },
  { q: 'How do credits work?',
    a: 'Each submission uses 5–15 credits depending on length. Failed jobs are automatically refunded. New accounts get 100 free credits; buy more from the Wallet.' },
  { q: 'How accurate is the analysis?',
    a: 'Around 95% transcription accuracy under good audio conditions. Accuracy degrades with low quality audio or heavy background noise. Confidence scores are attached to each extracted insight.' },
];

window.Dashboard = Dashboard;
