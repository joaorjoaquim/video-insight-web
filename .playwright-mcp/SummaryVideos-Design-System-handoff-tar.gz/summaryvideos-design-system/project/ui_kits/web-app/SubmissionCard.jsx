// SubmissionCard.jsx — tape-label tab + hairline frame + LED footer
function SubmissionCard({ submission, index, onOpen }) {
  const s = submission;
  const completed = s.status === 'completed';
  const failed = s.status === 'failed';
  const inFlight = !completed && !failed;
  const num = String(index + 1).padStart(2, '0');

  return (
    <div className="card-wrap">
      <div className={'card-tab ' + s.status}></div>
      <div className={'card ' + (completed ? 'card-clickable' : '')}
           onClick={() => completed && onOpen && onOpen(s.id)}>
        <div className="card-row">
          <span className="meta">§ {num} · {s.platform} · {s.duration}</span>
          <span className="meta" style={{fontSize: 10}}>{s.dateShort}</span>
        </div>
        <div className="card-row tall">
          <div style={{fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 400, lineHeight: 1.15, letterSpacing: '-0.012em', color: 'var(--fg-1)'}}>
            {s.title}
          </div>
          {inFlight && typeof s.progress === 'number' && (
            <div style={{width: '100%'}}>
              <div className="progress-rule">
                <i style={{width: s.progress + '%'}} />
              </div>
              <div className="meta" style={{marginTop: 8, fontSize: 10}}>{s.progress}% &nbsp;·&nbsp; ETA ~{Math.ceil((100 - s.progress) / 18)}:00</div>
            </div>
          )}
        </div>
        <div className="card-row">
          <span className="meta" style={{fontSize: 10}}>
            {completed ? `${s.insightCount} INSIGHTS · ${s.topicCount} TOPICS` : failed ? 'CREDITS REFUNDED' : ' '}
          </span>
          <span className={'led ' + s.status}>{s.status}</span>
        </div>
      </div>
    </div>
  );
}

window.SubmissionCard = SubmissionCard;
