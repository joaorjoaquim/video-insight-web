// Landing.jsx — unauth marketing surface, Briefing Room direction.
function Landing({ onSignIn }) {
  return (
    <main>
      {/* HERO */}
      <section style={{paddingTop: 88, paddingBottom: 96}}>
        <div className="container">
          <div className="reel-bar" style={{marginBottom: 28}}></div>
          <SectionMark n="00" label="Introduction" />
          <h1 className="display-1" style={{maxWidth: '18ch', marginTop: 28, marginBottom: 28}}>
            Turn any video into a <span className="ital-bar">brief</span> in minutes.
          </h1>
          <p className="lead" style={{marginBottom: 32, maxWidth: '40rem'}}>
            Paste a public URL from YouTube, Vimeo, or Twitter. We download, transcribe, and structure the result into a summary, a searchable transcript, and a thematic mind map. Most videos finish in under four minutes.
          </p>
          <div style={{display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap'}}>
            <button className="btn btn-primary" onClick={onSignIn}>
              Start Analyzing <span className="play-glyph"></span>
            </button>
            <button className="btn btn-ghost" onClick={onSignIn}>See how it works →</button>
          </div>
          <div className="meta" style={{marginTop: 48, display: 'flex', gap: 18, flexWrap: 'wrap'}}>
            <span>NO CREDIT CARD</span>
            <span style={{color: 'var(--rule)'}}>·</span>
            <span>100 FREE CREDITS</span>
            <span style={{color: 'var(--rule)'}}>·</span>
            <span>2-HOUR VIDEO CEILING</span>
          </div>
        </div>
      </section>

      <hr className="rule" />

      {/* FEATURES */}
      <section style={{padding: '88px 0'}}>
        <div className="container">
          <div style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32, marginBottom: 48}}>
            <SectionMark n="01" label="What you get" stacked />
            <h2 className="display-2" style={{maxWidth: '18ch'}}>
              Four artefacts from <span className="ital-bar">one paste</span>.
            </h2>
          </div>
          <div style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32}}>
            <div></div>
            <div style={{borderTop: '1px solid var(--rule)'}}>
              {FEATURES.map((f, i) => <FeatureRow key={i} index={i + 1} {...f} />)}
            </div>
          </div>
        </div>
      </section>

      <hr className="rule" />

      {/* CREDITS / PRICING */}
      <section style={{padding: '88px 0'}}>
        <div className="container">
          <div style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32, marginBottom: 48}}>
            <SectionMark n="02" label="Credits" stacked />
            <div>
              <h2 className="display-2" style={{maxWidth: '20ch', marginBottom: 16}}>
                Pay only for what you <span className="ital-bar">process</span>.
              </h2>
              <p className="lead" style={{maxWidth: '34rem'}}>
                Each video uses 5–15 credits based on length. Failed jobs are automatically refunded. New accounts get 100 credits free.
              </p>
            </div>
          </div>
          <div style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32}}>
            <div></div>
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12}}>
              {PACKAGES.map((p, i) => (
                <div key={i} className="pkg">
                  <div className="eyebrow">{p.name}</div>
                  <div className="pkg-amt">{p.amount} <small>credits</small></div>
                  <div className="pkg-per">${p.per.toFixed(2)} PER CREDIT</div>
                  <div style={{marginTop: 'auto', paddingTop: 10, borderTop: '1px solid var(--rule-soft)'}}>
                    <div className="pkg-price">${p.price.toFixed(2)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <hr className="rule" />

      {/* HOW IT WORKS */}
      <section style={{padding: '88px 0 120px'}}>
        <div className="container">
          <div style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32, marginBottom: 48}}>
            <SectionMark n="03" label="How it works" stacked />
            <h2 className="display-2" style={{maxWidth: '20ch'}}>
              Three steps. <span className="ital-bar">One result.</span>
            </h2>
          </div>
          <div style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32}}>
            <div></div>
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 36}}>
              {STEPS.map((s, i) => (
                <div key={i}>
                  <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14}}>
                    <span style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--play-700)', fontWeight: 500}}>{`0${i + 1}`}</span>
                    <div className="progress-rule" style={{width: 56}}><i style={{width: (i === 2 ? 100 : i === 1 ? 60 : 30) + '%'}}/></div>
                  </div>
                  <div className="display-3" style={{marginBottom: 10}}>{s.title}</div>
                  <p style={{margin: 0, color: 'var(--fg-2)', fontSize: 15, lineHeight: 1.55}}>{s.body}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <hr className="rule" />

      {/* CLOSER */}
      <section style={{padding: '120px 0'}}>
        <div className="container">
          <div style={{display: 'grid', gridTemplateColumns: '200px 1fr', gap: 32, alignItems: 'center'}}>
            <SectionMark n="—" label="" stacked />
            <div>
              <h2 className="display-1" style={{maxWidth: '14ch', marginBottom: 32, fontSize: 'clamp(2.5rem, 4vw + 1rem, 4.5rem)'}}>
                Ready when <span className="ital-bar">you are</span>.
              </h2>
              <div style={{display: 'flex', gap: 14, alignItems: 'center', flexWrap: 'wrap'}}>
                <button className="btn btn-primary" onClick={onSignIn}>
                  Get Started Free <span className="play-glyph"></span>
                </button>
                <span className="meta">TAKES ABOUT 20 SECONDS</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{padding: '32px 0', borderTop: '1px solid var(--rule)'}}>
        <div className="container" style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 10}}>
            <img src="../../assets/summary_videos_logo.png" alt="" style={{height: 22}} />
            <span style={{fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 400}}>SummaryVideos</span>
          </div>
          <span className="meta">© 2026 SUMMARYVIDEOS — ALL RIGHTS RESERVED</span>
        </div>
      </footer>
    </main>
  );
}

function SectionMark({ n, label, stacked }) {
  if (stacked) {
    return (
      <div>
        <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8}}>
          <span className="logo-bars"><i/><i/><i/></span>
          <span style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--fg-3)', fontWeight: 500}}>§ {n}</span>
        </div>
        <div style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--fg-2)', fontWeight: 500}}>{label}</div>
      </div>
    );
  }
  return (
    <div style={{display: 'inline-flex', alignItems: 'center', gap: 12}}>
      <span className="logo-bars"><i/><i/><i/></span>
      <span style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--fg-3)', fontWeight: 500}}>
        § {n}{label && ` — ${label.toUpperCase()}`}
      </span>
    </div>
  );
}

function FeatureRow({ index, kicker, title, body, tags }) {
  return (
    <div style={{display: 'grid', gridTemplateColumns: '80px 1fr 240px', gap: 32, padding: '32px 0', borderBottom: '1px solid var(--rule)'}}>
      <div style={{fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.14em', color: 'var(--play-700)', fontWeight: 500}}>0{index}</div>
      <div>
        <div className="eyebrow" style={{marginBottom: 6}}>{kicker}</div>
        <div className="display-3" style={{marginBottom: 10}}>{title}</div>
        <p style={{margin: 0, fontSize: 15, lineHeight: 1.55, color: 'var(--fg-2)', maxWidth: '40rem'}}>{body}</p>
      </div>
      <div style={{display: 'flex', flexWrap: 'wrap', gap: 6, alignItems: 'flex-start'}}>
        {tags.map((t, i) => (
          <span key={i} style={{fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--fg-3)', border: '1px solid var(--rule)', padding: '4px 8px', borderRadius: 4}}>{t}</span>
        ))}
      </div>
    </div>
  );
}

const FEATURES = [
  {
    kicker: 'SUMMARY',
    title: '2–4 paragraph brief.',
    body: 'A tight, faithful summary you can paste into a doc and ship. Includes runtime, complexity rating, and a topic list. Written to be skimmed, not skimmed-over.',
    tags: ['PROSE', 'PDF', 'COPY']
  },
  {
    kicker: 'TRANSCRIPT',
    title: 'Searchable, time-stamped.',
    body: 'Every sentence linked to the moment it was said. Click a timestamp to jump back to the source. Export to plain text or PDF when you need a paper trail.',
    tags: ['SEARCHABLE', 'TIMESTAMPED', 'EXPORTABLE']
  },
  {
    kicker: 'INSIGHTS',
    title: 'Themes, quotes, takeaways.',
    body: 'Notable quotes and key takeaways grouped by topic. Each insight carries a confidence score so you know what is signal and what is filler.',
    tags: ['THEMED', 'SCORED', 'QUOTED']
  },
  {
    kicker: 'MIND MAP',
    title: 'Visual concept breakdown.',
    body: 'A tree view of the ideas in the video — root concept, branches, leaves. Useful when you want to grok the structure of a long lecture before reading it.',
    tags: ['VISUAL', 'BRANCHED']
  },
];

const PACKAGES = [
  { name: 'STARTER',    amount: 10,  price: 9.90,  per: 0.99 },
  { name: 'POPULAR',    amount: 25,  price: 19.75, per: 0.79 },
  { name: 'PRO',        amount: 50,  price: 34.50, per: 0.69 },
  { name: 'ENTERPRISE', amount: 100, price: 59.00, per: 0.59 },
];

const STEPS = [
  { title: 'Paste a URL.',     body: 'YouTube, Vimeo, Twitter, or any public direct link. Up to two hours per video.' },
  { title: 'We do the work.',  body: 'Download, transcription, structure. You watch a status indicator; we handle the queue.' },
  { title: 'Read the brief.',  body: 'Summary, transcript, insights, and a mind map land on a single page. Export anywhere.' },
];

window.Landing = Landing;
