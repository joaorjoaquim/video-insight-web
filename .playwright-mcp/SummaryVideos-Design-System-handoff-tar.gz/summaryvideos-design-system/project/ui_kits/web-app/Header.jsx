// Header.jsx — flat ground header with mono nav, orange-underline on active
function Header({ view, onNav, authed, credits = 270, onSignIn }) {
  return (
    <header className="header">
      <div className="header-inner">
        <a className="brand" onClick={() => onNav(authed ? 'dashboard' : 'landing')}>
          <img className="brand-img" src="../../assets/summary_videos_logo.png" alt="SummaryVideos" />
          <span className="brand-name">SummaryVideos</span>
        </a>

        {authed ? (
          <nav className="nav">
            <a className={'nav-link ' + (view === 'dashboard' ? 'active' : '')} onClick={() => onNav('dashboard')}>Dashboard</a>
            <a className={'nav-link ' + (view === 'wallet' ? 'active' : '')} onClick={() => onNav('wallet')}>
              Wallet <span className="credits-num">/ {credits}</span>
            </a>
            <a className="nav-link" href="https://github.com/joaorjoaquim/video-insight-web" target="_blank" rel="noreferrer">GitHub</a>
            <span className="avatar" title="Profile">TE</span>
          </nav>
        ) : (
          <nav className="nav">
            <a className="nav-link" onClick={() => onNav('landing')}>How It Works</a>
            <a className="nav-link" href="https://github.com/joaorjoaquim/video-insight-web" target="_blank" rel="noreferrer">GitHub</a>
            <button className="btn btn-outline btn-sm" onClick={onSignIn}>Sign In</button>
          </nav>
        )}
      </div>
    </header>
  );
}

window.Header = Header;
