# Motion · "Tape Transport"

Motion is the difference between a static brand and a felt one. For SummaryVideos, motion is the visual proof that the product is doing what it promises — **compressing time, structuring an unstructured input**. Every animated element is a small dramatisation of the pipeline.

## Principles

1. **Motion proves work.** Loaders aren't decorative spinners; they show the actual pipeline steps (downloading → transcribing → analysing) using the logo's bar language.
2. **Bars never spin.** The product's symbol is horizontal bars. We move them horizontally — they extend, retract, stagger, slide — never rotate.
3. **Orange leads, purple follows.** The play triangle (orange) appears first; the bars (purple) fill in behind it. This mirrors the logo's reading order and the product's flow: action → structured result.
4. **Tape-transport easing.** Default ease is `cubic-bezier(0.16, 1, 0.3, 1)` (expo-out) — fast entry, gentle settle, like a reel coming up to speed.
5. **Stagger is the signature.** Multi-element reveals use a **60 ms stagger**. Insight bars, status pills, transcript lines, package tiles — all enter sequentially. Never simultaneously.
6. **No bounce on chrome.** Bounce easing (`--ease-tape`) is reserved for the play-triangle CTA glyph on press. Buttons, modals, transitions are linear-feeling.
7. **Reduced-motion is honoured.** Every animation has a `prefers-reduced-motion` fallback that snaps to the end state.

## Duration tokens

| Token | Value | Use |
|---|---|---|
| `--d-instant` | 100 ms | Hover/active state flips, focus rings |
| `--d-fast` | 200 ms | Tab change, button feedback, dropdown |
| `--d-normal` | 350 ms | Card enter, modal rise, content reveal |
| `--d-slow` | 600 ms | Layout shift, transcript jump, route change |
| `--d-pipeline` | 1.2 s | Loader loops, bar staggers, status pulses |
| `--stagger` | 60 ms | Between adjacent list items |

## Easing tokens

| Token | Curve | Use |
|---|---|---|
| `--ease-out` | `cubic-bezier(0.16, 1, 0.3, 1)` | Default — entries, reveals |
| `--ease-in-out` | `cubic-bezier(0.83, 0, 0.17, 1)` | Two-way transitions |
| `--ease-tape` | `cubic-bezier(0.34, 1.56, 0.64, 1)` | The play-glyph press (gentle anticipation) |
| `--ease-mechanical` | `cubic-bezier(0.4, 0, 0.2, 1)` | LED pulses, status loops |

## Signature scenes

### 1. The bars loader
The product's primary loading state. Four horizontal purple bars of varying width fill in left-to-right with 80 ms staggers. Loop duration 1.2 s. Replaces every spinner in the product.

```css
.bars-loader { display: inline-flex; flex-direction: column; gap: 4px; width: 48px; }
.bars-loader i { animation: bar-stagger 1.2s var(--ease-out) infinite; transform-origin: left; }
```

### 2. Status LED pulse
Active states (`transcribing`, `downloaded`) get a single coloured dot that breathes — `box-shadow` ring expands and fades every 1.4 s. Completed/failed states are static.

### 3. Submission card enter
When the submission list renders, cards rise in with `60 ms × index` stagger, 350 ms duration, expo-out. The third card finishes ~530 ms after the first starts — visible but never sluggish.

### 4. URL paste → submit
On submit, the input's underline bar **slides off-screen to the right** (160 ms), the bars-loader fades in beneath it (200 ms), and a fresh submission card slides down from above the list (350 ms, expo-out).

### 5. Tab change
Tabs (Summary / Transcript / Insights) cross-fade content over 200 ms with no layout shift. The active-tab underline animates from previous → current position in 250 ms.

### 6. Insight reveal
When the Insights tab opens, the **logo bars beside each section heading draw in left-to-right** (300 ms, 80 ms stagger between sections). The orange-italic emphasis underline on emphasized words draws in 150 ms after its parent appears.

### 7. Mind-map expand
Branches expand from the root using `scaleY(0 → 1)` from the top edge, 350 ms, expo-out. Leaves stagger in 80 ms apart.

### 8. Buy-credits modal
Modal rises 12 px from below with 350 ms expo-out + fade. Package tiles inside stagger in `60 ms × index`. The "RECOMMENDED" ribbon slides in from the top of its tile 200 ms after the tile finishes entering.

### 9. Credit purchase confirmation
On confirm, the balance number animates from `N → N + bought` over 600 ms using `ease-in-out`. The play-glyph on the "Buy Now" button pulses once with `--ease-tape`.

### 10. Theme toggle
Background, text, and rule colors transition over 200 ms with `--ease-in-out`. The logo bars stay the same purple — only the ground inverts.

## Things motion never does

- **No parallax.** This is a tool, not a brochure.
- **No "AI shimmer" gradients.** No iridescent loading bars, no animated noise.
- **No infinite spinners.** Use `.bars-loader`. Spinners imply unknown duration; bars imply structured work.
- **No hover scaling on cards.** Cards change colour, never size.
- **No floating elements.** Sticky headers don't float; they sit flush on a hairline rule.
- **No emoji wiggle.** No element wiggles, jiggles, or bounces in idle state.
